package com.movieTickets.application;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import com.movieTickets.admin.dto.Admin;
import com.movieTickets.customer.dto.Customer;
import com.movieTickets.customer.service.HomeServices;
import com.movieTickets.customer.service.HomeServicesImpl;
public class MainApplication 
{
	public static void main(String[] args) 
	{
		@SuppressWarnings({ "resource" })
		Scanner sc=new Scanner(System.in);
		System.out.println("1. Admin Login");
		System.out.println("2. Admin Register");
		System.out.println("3. Customer Login");
		System.out.println("4. Customer Register");
		System.out.println("-----------------------------------");
		System.out.println("Enter Your Choice");
		int choice =sc.nextInt();
		switch(choice)
		{
		case 1:
		{
			//Admin Login Details
			HomeServices service =new HomeServicesImpl();
			System.out.println("Enter Admin login Id");
			int adminId=sc.nextInt();
			System.out.println("Enter Admin Password");
			String adminPassword=sc.next();
			boolean login=service.validateLoginAdmin(adminId, adminPassword);
			if(login)
			{
				System.out.println("Logged in successfully");
			}
			else
			{
				System.out.println("Invalid credentials");
			}
		}
		     break;
		case 2:
		{
			//Admin Registeration Details
			HomeServices service=new HomeServicesImpl();
	    	Date dates = null;
			Admin admin=new Admin();
			System.out.println("Enter adminId");
			int adminId=sc.nextInt();
			while(!service.validateAdminId(adminId))
			{
				System.out.println("Invalid Id number");
				System.out.println("Enter the valid Id number");
				adminId = sc.nextInt();
			}
			System.out.println("Enter Admin Name");
			String adminName=sc.next();
			while(!service.validateName(adminName))
			{
				System.out.println("Invalid user name \n It should not start with a special character or a space");
				System.out.println("Enter the valid user name");
				adminName= sc.next();
			}
			System.out.println("Enter Admin Password");
			String adminPassword=sc.next();
			while(!service.validatePassword(adminPassword))
			{
				System.out.println("Invalid password \n It should contain a special character, an alphabet and a number");
				System.out.println("The minimum length of the password can be 8 and max limit is 14");
				System.out.println("Enter the valid password");
				adminPassword = sc.next();
			}
			System.out.println("Enter Date of Birth");
			String date=sc.next(); 
	        SimpleDateFormat format = new SimpleDateFormat("dd:MM:yyyy");
			try
			{
				 dates=format.parse(date);
			} 
			catch (ParseException e)
			{
				e.printStackTrace();
			}
			System.out.println("Enter Admin Contact Details");
			String contactAdmin=sc.next();
			while(!service.validateContactAdmin(contactAdmin))
			{
				System.out.println("Invalid Contact details");
				System.out.println("Enter Correct Details");
				contactAdmin=sc.next();
			}
			admin.setAdminId(adminId);
			admin.setAdminName(adminName);
			admin.setAdminPassword(adminPassword);
			admin.setDob(dates);
			admin.setContactadmin(contactAdmin);
			int rows=service.registerAdmin(admin);
			if(rows>=0)
			{
				System.out.println("Registered Successfully");
			}
			else
			{
				System.out.println("Not registered");
			}
		}
		   break;
		case 3:
		{
			// Customer Login Details
			HomeServices service=new HomeServicesImpl();
			System.out.println("Enter Customer Id");
			int customerId=sc.nextInt();
			System.out.println("Enter Customer Password");
			String customerPassword=sc.next();
			boolean login=service.validateLoginCustomer(customerId, customerPassword);
			if(login)
			{
				System.out.println("Logged in succesfully");
			}
			else
			{
				System.out.println("Invalid credentials");
			}
		 }
		   break;
		case 4:
		{
			// Customer Registeration Details
			HomeServices service=new HomeServicesImpl();
			Date dates = null;
			Customer customer=new Customer();
			System.out.println("Enter Customer Id");
			int customerId=sc.nextInt();
			while(!service.validateId(customerId))
			{
				System.out.println("Invalid Id number");
				System.out.println("Enter the valid Id number");
				customerId = sc.nextInt();
			}
			System.out.println("Enter Customer Name");
			String customerName=sc.next();
			while(!service.validateName(customerName))
			{
				System.out.println("Invalid user name \n It should not start with a special character or a space");
				System.out.println("Enter the valid user name");
				customerName= sc.next();
			}
			System.out.println("Enter Customer Password");
			String customerPassword=sc.next();
			while(!service.validatePassword(customerPassword))
			{
				System.out.println("Invalid password \n It should contain a special character, an alphabet and a number");
				System.out.println("The minimum length of the password can be 8 and max limit is 14");
				System.out.println("Enter the valid password");
				customerPassword = sc.next();
			}
			System.out.println("Enter Date of Birth");
		    String date=sc.next();
		    SimpleDateFormat format = new SimpleDateFormat("dd:MM:yyyy");
	        try
	        {
					dates=format.parse(date);
			} 
	        catch (ParseException e)
				{
					e.printStackTrace();
				}
			System.out.println("Enter Customer Contact Details");
			String customerContact=sc.next();
			while(!service.validateCustomerContact(customerContact))
			{
				System.out.println("Invalid Details");
				System.out.println("Enter Correct Details");
				customerContact=sc.next();
			}
			customer.setCustomerId(customerId);
			customer.setCustomerName(customerName);
			customer.setCustomerPassword(customerPassword);
	     	customer.setDob(dates);
			customer.setCustomerContact(customerContact);
			int rows=service.registerCustomer(customer);
			if(rows>=0)
			{
				System.out.println("Registered Succesfully");
			}
			else
			{
				System.out.println("Not registered");
			}
		 }
		   break;
		default:
			System.out.println("Invalid Choice");	
	  }
   }
}