package com.movieTickets.customer.service;
import com.movieTickets.admin.dto.Admin;
import com.movieTickets.customer.dao.HomeDao;
import com.movieTickets.customer.dao.HomeDaoImpl;
import com.movieTickets.customer.dto.Customer;
public class HomeServicesImpl implements HomeServices
{
	HomeDao dao=new HomeDaoImpl();
	@Override
	public int registerCustomer(Customer customer)
	{
		int rows=dao.registerCustomer(customer);
		return rows;
	}
	@Override
	public int registerAdmin(Admin admin) 
	{
		int rows=dao.registerAdmin(admin);
		return rows;
	}
	@Override
	public boolean validatePassword(String customerPassword)
	{
		String num = "7418520963";
		int size = num.length()-1;
		if(customerPassword.length()>=8 && customerPassword.length()<=14)
			if(customerPassword.contains("!")||customerPassword.contains("@")||customerPassword.contains("#")||customerPassword.contains("$")||customerPassword.contains("%")||customerPassword.contains("^")||customerPassword.contains("&")||customerPassword.contains("*"))
				while(size>0)
				{
					if(customerPassword.contains(""+num.charAt(size)))
						return true;
					size--;
				}
		return false;
	}
	@Override
	public boolean validateId(int customerId)
	{
		int count=0;
		while(customerId!=0)
		{
			customerId=customerId/10;
			count++;
		}
		if(count>=6)
		{
			return true;
		}
		else
			return false;
	}
	@Override
	public boolean validateName(String customerName)
	{
		if(customerName.startsWith("!")||customerName.startsWith("@")||customerName.startsWith("#")||customerName.startsWith("$")||customerName.startsWith("%")||customerName.startsWith("^")||customerName.startsWith("&")||customerName.startsWith("*")||customerName.startsWith(" "))
			return false;
		return true;
	}
	@Override
	public boolean validateAdminPassword(String adminPassword) 
	{
		String num = "7418520963";
		int size = num.length()-1;
		if(adminPassword.length()>=8 && adminPassword.length()<=14)
			if(adminPassword.contains("!")||adminPassword.contains("@")||adminPassword.contains("#")||adminPassword.contains("$")||adminPassword.contains("%")||adminPassword.contains("^")||adminPassword.contains("&")||adminPassword.contains("*"))
				while(size>0)
				{
					if(adminPassword.contains(""+num.charAt(size)))
						return true;
					size--; 
				}
		return false;
	}
	@Override
	public boolean validateAdminId(int adminId)
	{
		int remainder=0,count=0;
		int temp=adminId;
		while(adminId!=0)
		{
			temp=adminId%10;
			adminId=adminId/10;
			remainder=temp;
			count++;
		}
		if(count>=4 && remainder==1)
		{
			return true;
		}
		else
		{
			return false;
		} 
	}
	@Override
	public boolean validateAdminName(String adminName) 
	{
		if(adminName.startsWith("!")||adminName.startsWith("@")||adminName.startsWith("#")||adminName.startsWith("$")||adminName.startsWith("%")||adminName.startsWith("^")||adminName.startsWith("&")||adminName.startsWith("*")||adminName.startsWith(" "))
			return false;
		return true;
	}
	@Override
	public boolean validateLoginCustomer(int customerId, String customerPassword) 
	{
		return dao.loginCustomer(customerId,customerPassword);
	}
	@Override
	public boolean validateLoginAdmin(int adminId, String adminPassword) 
	{
		return dao.loginAdmin(adminId, adminPassword);
	}
	@Override
	public boolean validateContactAdmin(String contactAdmin)
	{
		if(contactAdmin.contains("@") && contactAdmin.contains("."))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	@Override
	public boolean validateCustomerContact(String customerContact) 
	{
		if(customerContact.contains("@") && customerContact.contains("."))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}