package com.movieTickets.customer.dto;

import java.util.Date;

public class Customer 
{
	private int customerId;
	private String customerName;
	private String customerPassword;
	private Date dob;
	private String customerContact;
	public Customer() 
	{
	}
	public Customer(int customerId, String customerName, String customerPassword, Date dob, String customerContact) 
	{
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerPassword = customerPassword;
		this.dob = dob;
		this.customerContact = customerContact;
	}
	public int getCustomerId()
	{
		return customerId;
	}
	public void setCustomerId(int customerId)
	{
		this.customerId = customerId;
	}
	public String getCustomerName() 
	{
		return customerName;
	}
	public void setCustomerName(String customerName) 
	{
		this.customerName = customerName;
	}
	public String getCustomerPassword() 
	{
		return customerPassword;
	}
	public void setCustomerPassword(String customerPassword) 
	{
		this.customerPassword = customerPassword;
	}
	public Date getDob()
	{
		return dob;
	}
	public void setDob(Date dob) 
	{
		this.dob = dob;
	}
	public String getCustomerContact()
	{
		return customerContact;
	}
	public void setCustomerContact(String customerContact) 
	{
		this.customerContact = customerContact;
	}
	

}
