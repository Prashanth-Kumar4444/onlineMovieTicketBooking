package com.movieTickets.customer.utils;
@SuppressWarnings("serial")
public class InvalidLoginException extends Exception
{
	public InvalidLoginException()
	{
		super("Invalid Login Credentials");
	}
}
