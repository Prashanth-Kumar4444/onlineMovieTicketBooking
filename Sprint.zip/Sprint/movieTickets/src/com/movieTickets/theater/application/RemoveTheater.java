package com.movieTickets.theater.application;
import java.util.Scanner;
import com.movieTickets.theater.Theater;
import com.movieTickets.theater.services.TheaterServices;
import com.movieTickets.theater.services.TheaterServicesImpl;
public class RemoveTheater {
	public static void main(String[] args) 
	{
		Theater theater=new Theater();
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter TheaterId");
		int theaterId=sc.nextInt();
		theater.setTheaterId(theaterId);
	    TheaterServices service=new TheaterServicesImpl();
	    int rows=service.deleteTheater(theaterId);
	    if(rows>0)
	    {
	    	System.out.println("Deleted succesfully");
	    }
	    else
	    {
	    	System.out.println("Not deleted");
	    }
	}
}