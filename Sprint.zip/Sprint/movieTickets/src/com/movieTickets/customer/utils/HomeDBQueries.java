package com.movieTickets.customer.utils;

public class HomeDBQueries 
{
	public static String addcustomerQuery="insert into customer values(?,?,?,?,?)";
	public static String addAdminQuery="insert into admin values(?,?,?,?,?)";
	public static String customerLoginQuery="select * from customer where customerId=? and customerPassword =? ";
	public static String adminLoginQuery="select * from customer where adminId=? and adminPassword=?";

}
