package com.movieTickets.theater.dao;
import com.movieTickets.theater.*;
public interface TheaterDao 
{
	public void openConnection();
	public void close();
	public int addTheater(Theater theater);
	public int deleteTheater(int theaterId);

}
