package com.movieTickets.theater.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.movieTickets.theater.Theater;
import com.movieTickets.theater.utils.TheaterDBQueries;
public class TheaterDaoImpl implements TheaterDao
{
	private Connection connection=null;
	private PreparedStatement pst;
	@Override
	public void openConnection()
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:xe";
			connection =DriverManager.getConnection(url, "scott", "tiger");
		} 
		catch (ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}		
	}
	@Override
	public void close()
	{
		try 
		{
			connection.close();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}	
	}
	@Override
	public int addTheater(Theater theater)
	{
		openConnection();
		int rows=0;
		try
		{
			pst=connection.prepareStatement(TheaterDBQueries.addtheaterQuery);
			pst.setInt(1, theater.getTheaterId());
			pst.setString(2, theater.getTheaterName());
			pst.setString(3, theater.getTheaterCity());
			pst.setString(4, theater.getManagerName());
			pst.setString(5, theater.getManagerContact());
			pst.setString(6, theater.getMovie());
			rows=pst.executeUpdate();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		close();
		return rows;
	}
	@Override
	public int deleteTheater(int theaterId)
	{
		openConnection();
		int rows=0;
		try
		{
			pst=connection.prepareStatement(TheaterDBQueries.deletetheaterQuery);
			pst.setInt(1, theaterId);
			rows=pst.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		close();
		return rows;
	}
}