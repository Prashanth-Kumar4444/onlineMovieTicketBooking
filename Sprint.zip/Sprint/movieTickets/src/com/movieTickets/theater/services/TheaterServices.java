package com.movieTickets.theater.services;

import com.movieTickets.theater.Theater;

public interface TheaterServices 
{
	public int addTheater(Theater theater);
	public int deleteTheater(int theaterId);
	public boolean validateId(int theaterId);

}
