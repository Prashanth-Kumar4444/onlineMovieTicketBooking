package com.movieTickets.customer.dao;

import com.movieTickets.admin.dto.Admin;
import com.movieTickets.customer.dto.Customer;

public interface HomeDao 
{
	public void openConnection();
	public void close();
	public int registerCustomer(Customer customer);
	public int registerAdmin(Admin admin);
	public boolean loginAdmin(int adminId,String adminPassword);
	public boolean loginCustomer(int customerId, String customerPassword);

}
