package com.movieTickets.theater.services;
import com.movieTickets.theater.Theater;
import com.movieTickets.theater.dao.TheaterDao;
import com.movieTickets.theater.dao.TheaterDaoImpl;
public class TheaterServicesImpl implements TheaterServices
{
	TheaterDao dao=new TheaterDaoImpl();
	@Override
	public int addTheater(Theater theater) 
	{
		int rows=dao.addTheater(theater);
		return rows;
	}
	@Override
	public int deleteTheater(int theaterId)
	{
		int rows=dao.deleteTheater(theaterId);
		return rows;
	}
	@Override
	public boolean validateId(int theaterId) 
	{
		int remainder=0,count=0;
		int temp=theaterId;
		while(theaterId!=0)
		{
			temp=theaterId%10;
			theaterId=theaterId/10;
			remainder=temp;
			count++;
		}
		if(count>=4 && remainder==2)
		{
			return true;
		}
		else
		{
			return false;
		} 
	}
}