package com.movieTickets.customer.service;
import com.movieTickets.admin.dto.Admin;
import com.movieTickets.customer.dto.Customer;
public interface HomeServices 
{
	public int registerCustomer(Customer customer);
	public int registerAdmin(Admin admin);
	public boolean validatePassword(String customerPassword);
	public boolean validateId(int customerId);
	public boolean validateName(String customerName);
	public boolean validateAdminPassword(String adminPassword);
	public boolean validateAdminId(int adminId);
	public boolean validateAdminName(String adminName);
	public boolean validateLoginCustomer(int customerId, String customerPassword);
	public boolean validateLoginAdmin(int adminId,String adminPassword);
	public boolean validateContactAdmin(String contactAdmin );
	public boolean validateCustomerContact(String customerContact);
}