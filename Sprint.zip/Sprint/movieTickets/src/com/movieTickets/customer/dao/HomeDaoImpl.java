package com.movieTickets.customer.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.movieTickets.admin.dto.Admin;
import com.movieTickets.customer.dto.Customer;
import com.movieTickets.customer.utils.HomeDBQueries;
public class HomeDaoImpl implements HomeDao
{
	private Connection connection=null;
	private PreparedStatement pst;
	private ResultSet result;
	@Override
	public void openConnection() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:xe";
			connection =DriverManager.getConnection(url, "scott", "tiger");
		} 
		catch (ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}	
		
	}
	@Override
	public void close()
	{
		try 
		{
			connection.close();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}	
		
	}
	@Override
	public int registerCustomer(Customer customer) 
	{
		openConnection();
		int rows=0;
		try
		{
			pst=connection.prepareStatement(HomeDBQueries.addcustomerQuery);
			pst.setInt(1, customer.getCustomerId());
			pst.setString(2, customer.getCustomerName());
			pst.setString(3, customer.getCustomerPassword());
			java.sql.Date sqlDate = new java.sql.Date(customer.getDob().getTime());
			pst.setDate(4, sqlDate);
			pst.setString(5, customer.getCustomerContact());
			//result=pst.getGeneratedKeys();
			rows=pst.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		close();
		return rows;
	}
	@Override
	public int registerAdmin(Admin admin)
	{
		openConnection();
		int rows=0;
		try
		{
			pst=connection.prepareStatement(HomeDBQueries.addAdminQuery);
			pst.setInt(1, admin.getAdminId());
			pst.setString(2, admin.getAdminName());
			pst.setString(3, admin.getAdminPassword());
			java.sql.Date sqlDate = new java.sql.Date( admin.getDob().getTime() );
			pst.setDate(4, sqlDate);
			pst.setString(5, admin.getContactadmin());
			rows=pst.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return rows;
	}
	@Override
	public boolean  loginAdmin(int adminId,String adminPassword)
	{
		openConnection();
		try
		{
			pst=connection.prepareStatement(HomeDBQueries.adminLoginQuery);
			pst.setInt(1, adminId);
			pst.setString(2, adminPassword);
			result=pst.executeQuery();
			if(result.next())
			{
				return true;
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		close();
		return false;
	}
	@Override
	public boolean loginCustomer(int customerId,String customerPassword) 
	{
		openConnection();
		try
		{
			pst=connection.prepareStatement(HomeDBQueries.customerLoginQuery);
			pst.setInt(1,customerId);
			pst.setString(2,customerPassword);
			result=pst.executeQuery();
			if(result.next())
				return true;
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		close();
		return false;
	}
}