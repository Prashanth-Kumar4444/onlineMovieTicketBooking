package com.movieTickets.theater.application;
import java.util.Scanner;
import com.movieTickets.theater.Theater;
import com.movieTickets.theater.services.TheaterServices;
import com.movieTickets.theater.services.TheaterServicesImpl;
public class InsertingTheater 
{
	@SuppressWarnings("unused")
	public static void main(String[] args) 
	{
		Theater theater = new Theater();
		TheaterServices services=new TheaterServicesImpl();
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter theater id");
		int theaterId=sc.nextInt();
		while(!services.validateId(theaterId))
		{
			System.out.println("Invalid Theater Id");
			System.out.println("Enter Correct Theater Id");
			theaterId=sc.nextInt();
		}
		System.out.println("Enter Theater name");
		String theaterName=sc.next();
		System.out.println("Enter theater city");
		String theaterCity=sc.next();
		System.out.println("Enter manager name");
		String managerName=sc.next();
		System.out.println("Enter managerContact");
		String managerContact=sc.next();
		System.out.println("Enter movie name");
		String movie=sc.next();
		theater.setTheaterId(theaterId);
		theater.setTheaterName(theaterName);
		theater.setTheaterCity(theaterCity);
		theater.setManagerName(managerName);
		theater.setManagerContact(managerContact);
		theater.setMovie(movie);
		int rows=services.addTheater(theater);
		if(rows>=0)
		{
			System.out.println("added");
		}
		else
		{
			System.out.println("Not added");
		}
	}
}