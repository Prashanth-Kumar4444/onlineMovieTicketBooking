package com.movieTickets.theater.dao;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
class Junit {
	@Test
	public void test()
	{
		TheaterDaoImpl dao=new TheaterDaoImpl();
		int rows=dao.deleteTheater(23456);
		assertEquals(rows, 1);	
	}
	@Test
	public void testNegative()
	{
		TheaterDaoImpl dao=new TheaterDaoImpl();
		int rows=dao.deleteTheater(23457);
		assertNotEquals(rows, 1);	
	}
}