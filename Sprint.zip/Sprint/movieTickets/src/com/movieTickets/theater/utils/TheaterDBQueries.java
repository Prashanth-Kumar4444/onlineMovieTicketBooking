package com.movieTickets.theater.utils;

public class TheaterDBQueries 
{
	public static String addtheaterQuery="insert into theater values(?,?,?,?,?,?)";
	public static String deletetheaterQuery="delete from theater where theaterId=?";

}
